package com.Shivani.FoodDeliverySystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodDeliverySystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
